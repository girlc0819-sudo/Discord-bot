# Discord Voice Bot

A small Node.js voice bot that registers Discord slash commands and plays
audio files you provide in a server voice channel.

The bot also serves an HTTP health check at `GET /health`. It returns HTTP 200
when the Discord client is ready and HTTP 503 while it is still connecting.
For the workspace's public development URL, monitor `/api/health`; the shared
API server forwards that path to the bot's `/health` endpoint.

## Commands

- `/join` — join the voice channel you are currently in.
- `/play track:<file>` — join your voice channel and play a file from `audio/`.
- `/stop` — stop the current audio.
- `/leave` — stop playback and leave the voice channel.

`/play` offers autocomplete for files in `audio/`. Supported file extensions are
AAC, FLAC, M4A, MP3, OGG, Opus, and WAV; FFmpeg converts them to voice-compatible
Opus audio. Put your own intro at `audio/intro.mp3`; when the member with Discord
username `sora107_` joins or moves to a voice channel, the bot joins that channel
and plays the intro. If the bot is already in that channel, it plays the intro
without reconnecting. The bot disconnects when `sora107_` leaves voice entirely
or when the bot's channel has no human members left.

## Discord setup

1. In the Discord Developer Portal, create an application and add a bot.
2. Invite it to your server using the `bot` and `applications.commands` scopes.
   Grant `View Channels`, `Send Messages`, `Connect`, and `Speak` permissions.
3. Copy the bot token into the Replit Secret named `DISCORD_BOT_TOKEN`. Never
   commit the token or paste it into chat.
4. Start the **Discord Voice Bot** workflow. On first login, it registers its
   slash commands; global commands can take a little time to appear.
5. Put an audio file in `services/discord-voice-bot/audio/`, join a voice
   channel, and use `/play`.

## Run locally

Install Node.js 20 or later and FFmpeg, then run:

```sh
pnpm install
pnpm --filter @workspace/discord-voice-bot run start
```

Set `DISCORD_BOT_TOKEN` in the shell environment before starting the bot.

## Operational notes

- Audio files stay local to the project; no external streaming source is used.
- The bot replaces the current track when another `/play` command is used.
- Discord.js reconnects gateway shards automatically; a two-minute readiness
  watchdog recreates the client if that reconnect stalls, and all event
  listeners are reattached on the new client.
- Voice connections are retried after disconnects and restored after a gateway
  resume while `sora107_` is still in a voice channel. The voice-state listener
  is registered on startup and again whenever the Discord client is recreated.
- Restart the workflow after adding a new audio file if autocomplete doesn't
  show it immediately.
