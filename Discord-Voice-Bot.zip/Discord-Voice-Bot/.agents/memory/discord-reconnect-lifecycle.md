---
name: Discord reconnect lifecycle
description: Recovery behavior for discord.js gateway sessions and @discordjs/voice connections.
---

Treat Discord gateway recovery and voice-connection recovery as separate concerns. Discord.js reconnects gateway shards automatically, but its voice manager destroys the guild's voice adapter when a shard disconnects. After the gateway resumes, an old voice connection may therefore be unusable; reconnect the user’s active voice session with a fresh connection if resuming the old one fails. If a watchdog fully destroys a Discord client, create a new Client instance and register every event listener again.

**Why:** A gateway session can recover while voice remains detached, and a destroyed discord.js WebSocket manager cannot be reused for another login.

**How to apply:** When modifying reconnect logic, handle shard lifecycle events, restore active voice sessions after readiness/resume, and verify listener registration on any replacement Client.
