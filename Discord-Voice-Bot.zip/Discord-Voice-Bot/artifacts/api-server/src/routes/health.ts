import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

router.get("/health", async (_req, res) => {
  try {
    const botResponse = await fetch("http://127.0.0.1:3000/health", {
      signal: AbortSignal.timeout(5_000),
    });
    const botStatus = await botResponse.json();
    res.status(botResponse.status).json(botStatus);
  } catch (error) {
    console.error("Discord bot health probe failed:", error);
    res.status(503).json({
      status: "unavailable",
      service: "discord-voice-bot",
    });
  }
});

export default router;
